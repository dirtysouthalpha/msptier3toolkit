﻿<#
.SYNOPSIS
    MSP Toolkit - Real REST API + Web UI server (HttpListener).
.DESCRIPTION
    Replaces the original Start-WebInterface.ps1 (which had only
    placeholder alert() handlers). This server:

      * Listens on the configured port (default 8080)
      * Requires X-Api-Key header for /api/* routes (unless on localhost
        AND config.security.requireApiKeyForLocalhost = false)
      * Real script execution via /api/scripts/run — launches the script
        as a background runspace and returns a job id
      * /api/jobs/<id>          - poll status
      * /api/jobs/<id>/result   - get the structured result
      * /api/health             - live OS metrics
      * /api/inventory          - current snapshot
      * /                       - SPA-style dashboard

    Stops cleanly on Ctrl+C.

.PARAMETER Port
    Override port (otherwise config.webInterface.port).
.PARAMETER BindAll
    Bind to 0.0.0.0 (default localhost only).
.PARAMETER OpenBrowser
    Launch default browser after startup.

.NOTES
    HttpListener URL ACL: binding to non-localhost requires either elevation
    or `netsh http add urlacl url=http://+:8080/ user=Everyone`.
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [int]$Port,
    [switch]$BindAll,
    [switch]$OpenBrowser
)

$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..\Core\MSPToolkit.psd1') -Force

Initialize-MSPLogging -ScriptName 'MSPApi' | Out-Null
$cfg = Get-MSPConfig
if (-not $Port) { $Port = if ($cfg.webInterface.port) { [int]$cfg.webInterface.port } else { 8080 } }
$apiKey = $cfg.webInterface.apiKey

if (-not $apiKey) {
    Write-MSPLog 'No API key set — generating ephemeral key for this session.' -Level WARNING
    $apiKey = ([guid]::NewGuid().ToString('N'))
    Write-Host ""
    Write-Host "  EPHEMERAL API KEY: $apiKey" -ForegroundColor Yellow
    Write-Host "  (Set webInterface.apiKey in config.json to make permanent.)" -ForegroundColor DarkGray
    Write-Host ""
}

# -----------------------------------------------------------------------
#  In-memory job registry
# -----------------------------------------------------------------------
$Script:Jobs = [System.Collections.Concurrent.ConcurrentDictionary[string,object]]::new()
$Script:RunspacePool = [runspacefactory]::CreateRunspacePool(1, 8)
$Script:RunspacePool.Open()

function New-MSPApiJob {
    param([string]$Tool, [scriptblock]$Block, [hashtable]$Args)
    $id = ([guid]::NewGuid().ToString('N').Substring(0,12))
    $ps = [powershell]::Create()
    $ps.RunspacePool = $Script:RunspacePool
    [void]$ps.AddScript({
        param($block, $args)
        try {
            & $block @args
        } catch {
            [pscustomobject]@{ status = 'Failure'; summary = $_.Exception.Message }
        }
    })
    [void]$ps.AddArgument($Block)
    [void]$ps.AddArgument($Args)

    $handle = $ps.BeginInvoke()
    $job = [pscustomobject]@{
        Id        = $id
        Tool      = $Tool
        StartedAt = (Get-Date).ToString('o')
        Status    = 'Running'
        Handle    = $handle
        Pipe      = $ps
        Result    = $null
    }
    $Script:Jobs[$id] = $job
    return $id
}

function Update-MSPJobStatus {
    param([string]$Id)
    if (-not $Script:Jobs.ContainsKey($Id)) { return $null }
    $job = $Script:Jobs[$Id]
    if ($job.Status -eq 'Running' -and $job.Handle.IsCompleted) {
        try {
            $out = $job.Pipe.EndInvoke($job.Handle)
            $job.Result = $out | Select-Object -Last 1
            $job.Status = if ($job.Result -and $job.Result.PSObject.Properties.Name -contains 'status') {
                "$($job.Result.status)"
            } else { 'Completed' }
        } catch {
            $job.Status = 'Failed'
            $job.Result = @{ summary = $_.Exception.Message }
        } finally {
            $job.Pipe.Dispose()
        }
    }
    return $job
}

# -----------------------------------------------------------------------
#  Script catalog — drives the UI and the /api/scripts list
# -----------------------------------------------------------------------
$Script:Catalog = @(
    @{ id='health';       name='System Health Report';   category='Diagnostics'; path='..\MSP_Tier3_Toolkit\SystemHealthReport.ps1' },
    @{ id='reboot';       name='Reboot Pending Check';   category='Diagnostics'; path='..\MSP_Tier3_Toolkit\Diagnostics\RebootPendingCheck.ps1' },
    @{ id='eventlog';     name='Event Log Alert Summary';category='Diagnostics'; path='..\MSP_Tier3_Toolkit\Diagnostics\EventLogAlertSummary.ps1' },
    @{ id='perf';         name='Performance Baseline';   category='Diagnostics'; path='..\MSP_Tier3_Toolkit\Diagnostics\Get-PerformanceBaseline.ps1' },
    @{ id='logons';       name='User Logon Report';      category='Diagnostics'; path='..\MSP_Tier3_Toolkit\Diagnostics\Get-UserLogonReport.ps1' },
    @{ id='services';     name='Windows Service Audit';  category='Diagnostics'; path='..\MSP_Tier3_Toolkit\Diagnostics\WindowsServiceAudit.ps1' },
    @{ id='bitlocker';    name='BitLocker Status';       category='Security';    path='..\MSP_Tier3_Toolkit\Security\BitLockerStatusCheck.ps1' },
    @{ id='av';           name='AV Status';              category='Security';    path='..\MSP_Tier3_Toolkit\Security\AVStatusCheck.ps1' },
    @{ id='admins';       name='Local Admin Audit';      category='Security';    path='..\MSP_Tier3_Toolkit\Security\LocalAdminAudit.ps1' },
    @{ id='patches';      name='Patch Compliance';       category='Security';    path='..\MSP_Tier3_Toolkit\Security\Get-PatchCompliance.ps1' },
    @{ id='posture';      name='Security Posture Score'; category='Security';    path='..\MSP_Tier3_Toolkit\Security\Get-SecurityPostureScore.ps1' },
    @{ id='cleanup';      name='Scheduled Temp Cleanup'; category='Maintenance'; path='..\MSP_Tier3_Toolkit\Maintenance\ScheduledTempCleanup.ps1' },
    @{ id='bloat';        name='OEM Bloatware Remover';  category='Maintenance'; path='..\MSP_Tier3_Toolkit\Maintenance\OEMBloatwareRemover.ps1' },
    @{ id='onedrive';     name='OneDrive Sync Health';   category='M365';        path='..\MSP_Tier3_Toolkit\M365\OneDriveSyncHealthCheck.ps1' },
    @{ id='inventory';    name='Asset Inventory';        category='Inventory';   path='..\MSP_Tier3_Toolkit\Inventory\Export-AssetInventory.ps1' },
    @{ id='network';      name='Network Path Diagnostic';category='Network';     path='..\MSP_Tier3_Toolkit\Network\Test-NetworkPath.ps1' }
)

# -----------------------------------------------------------------------
#  HTTP listener
# -----------------------------------------------------------------------
$prefix = if ($BindAll) { "http://+:$Port/" } else { "http://localhost:$Port/" }
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add($prefix)
$listener.Start()

Show-MSPBanner -Version '3.0.0'
Write-MSPLog "API + UI listening on $prefix" -Level SUCCESS
Write-MSPLog "Auth: X-Api-Key header required for /api/*" -Level INFO

if ($OpenBrowser) { Start-Process "http://localhost:$Port" }

# UI HTML — single page, vanilla JS, no build step
$uiHtml = @'
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>MSP Toolkit Console</title>
<style>
:root { --bg:#0e1322; --panel:#181f36; --line:#293252; --muted:#7d89b3; --accent:#5b6cfa; --ok:#21c186; --warn:#e8a93b; --bad:#e8505b; --text:#eaeefa; }
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}
.topbar{display:flex;justify-content:space-between;align-items:center;padding:14px 28px;border-bottom:1px solid var(--line);background:var(--panel);}
.brand{display:flex;align-items:center;gap:12px;font-weight:700;font-size:18px;letter-spacing:.4px;}
.brand .dot{width:10px;height:10px;border-radius:50%;background:var(--accent);}
.auth{display:flex;gap:8px;align-items:center;}
.auth input{background:#0e1322;border:1px solid var(--line);color:var(--text);padding:7px 10px;border-radius:6px;width:300px;font-family:monospace;font-size:12px;}
.layout{display:grid;grid-template-columns:280px 1fr;gap:0;min-height:calc(100vh - 53px);}
.sidebar{background:var(--panel);border-right:1px solid var(--line);padding:18px;overflow-y:auto;}
.cat{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:1.2px;margin:14px 0 6px;}
.tool{padding:8px 10px;border-radius:6px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-size:14px;}
.tool:hover{background:#222a47;}
.tool.active{background:var(--accent);color:#fff;}
.main{padding:28px;overflow-y:auto;}
.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:24px;}
.metric{background:var(--panel);padding:16px;border-radius:10px;border:1px solid var(--line);}
.metric .l{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.8px;}
.metric .v{font-size:24px;font-weight:600;margin-top:4px;}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:20px;margin-bottom:20px;}
.panel h2{font-size:16px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;}
.btn{background:var(--accent);color:#fff;border:none;padding:9px 16px;border-radius:6px;cursor:pointer;font-weight:600;font-size:13px;}
.btn:hover{filter:brightness(1.1);}
.btn.secondary{background:#222a47;}
.row{display:flex;gap:8px;align-items:center;}
.output{background:#0e1322;border:1px solid var(--line);border-radius:8px;padding:14px;font-family:Menlo,Consolas,monospace;font-size:12px;white-space:pre-wrap;word-break:break-word;max-height:480px;overflow:auto;}
.pill{display:inline-block;padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
.pill.ok{background:rgba(33,193,134,.15);color:var(--ok);}
.pill.warn{background:rgba(232,169,59,.15);color:var(--warn);}
.pill.bad{background:rgba(232,80,91,.15);color:var(--bad);}
.pill.run{background:rgba(91,108,250,.15);color:var(--accent);}
.empty{color:var(--muted);text-align:center;padding:40px 20px;}
.jobs{display:flex;flex-direction:column;gap:8px;max-height:240px;overflow-y:auto;}
.job{display:flex;justify-content:space-between;padding:8px 12px;background:#222a47;border-radius:6px;font-size:13px;}
.tag{font-size:11px;color:var(--muted);}
</style>
</head>
<body>
<div class="topbar">
  <div class="brand"><span class="dot"></span> MSP Toolkit Console <span class="tag">v3.0</span></div>
  <div class="auth">
    <span class="tag">API key</span>
    <input id="apiKey" type="password" placeholder="X-Api-Key" autocomplete="off"/>
    <button class="btn secondary" onclick="saveKey()">Save</button>
  </div>
</div>

<div class="layout">
  <aside class="sidebar">
    <div class="cat">Quick</div>
    <div class="tool" onclick="loadHealth()">Refresh dashboard</div>
    <div id="toolList"></div>
  </aside>

  <main class="main">
    <div class="metrics" id="metrics"></div>

    <div class="panel">
      <h2><span id="selectedName">Select a tool</span> <span class="pill run" id="selectedCat"></span></h2>
      <div class="row" style="margin-bottom:12px;">
        <button class="btn" onclick="runSelected()" id="runBtn" disabled>Run</button>
        <span class="tag" id="hint">Pick a tool from the sidebar.</span>
      </div>
      <div class="output empty" id="output">No output yet.</div>
    </div>

    <div class="panel">
      <h2>Recent jobs</h2>
      <div class="jobs" id="jobs"><div class="empty">No jobs yet this session.</div></div>
    </div>
  </main>
</div>

<script>
const $ = (id) => document.getElementById(id);
let selected = null;
let catalog = [];
let pollers = {};

function getKey() { return $('apiKey').value || localStorage.getItem('mspApiKey') || ''; }
function saveKey() { localStorage.setItem('mspApiKey', $('apiKey').value); }
function loadKey()  { $('apiKey').value = localStorage.getItem('mspApiKey') || ''; }

async function api(path, opts={}) {
  opts.headers = Object.assign({'X-Api-Key': getKey()}, opts.headers||{});
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(r.status + ' ' + await r.text());
  const ct = r.headers.get('content-type')||'';
  return ct.includes('json') ? r.json() : r.text();
}

function pill(status) {
  const cls = status === 'Success' ? 'ok' :
              status === 'Warning' ? 'warn' :
              (status === 'Failure' || status === 'Failed') ? 'bad' :
              'run';
  return `<span class="pill ${cls}">${status}</span>`;
}

async function loadCatalog() {
  catalog = await api('/api/scripts');
  const grouped = {};
  catalog.forEach(c => { (grouped[c.category]=grouped[c.category]||[]).push(c); });
  let html = '';
  Object.keys(grouped).sort().forEach(cat => {
    html += `<div class="cat">${cat}</div>`;
    grouped[cat].forEach(c => {
      html += `<div class="tool" data-id="${c.id}" onclick="select('${c.id}')">${c.name}</div>`;
    });
  });
  $('toolList').innerHTML = html;
}

function select(id) {
  selected = catalog.find(c => c.id === id);
  document.querySelectorAll('.tool').forEach(e => e.classList.remove('active'));
  const el = document.querySelector(`.tool[data-id="${id}"]`); if (el) el.classList.add('active');
  $('selectedName').textContent = selected.name;
  $('selectedCat').textContent = selected.category;
  $('runBtn').disabled = false;
  $('hint').textContent = 'Click Run to execute on this machine.';
}

async function runSelected() {
  if (!selected) return;
  $('runBtn').disabled = true;
  $('output').textContent = 'Submitting...';
  try {
    const r = await api('/api/scripts/run', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ id: selected.id })
    });
    addJob(r.jobId, selected.name);
    pollJob(r.jobId);
  } catch (e) {
    $('output').textContent = 'Error: ' + e.message;
    $('runBtn').disabled = false;
  }
}

function addJob(id, name) {
  const j = $('jobs');
  if (j.querySelector('.empty')) j.innerHTML = '';
  const row = document.createElement('div');
  row.className = 'job';
  row.id = 'job-' + id;
  row.innerHTML = `<div>${name} <span class="tag">${id}</span></div><div>${pill('Running')}</div>`;
  j.prepend(row);
}

async function pollJob(id) {
  pollers[id] = setInterval(async () => {
    try {
      const j = await api('/api/jobs/' + id);
      const row = $('job-' + id);
      if (row) row.children[1].innerHTML = pill(j.status);
      if (j.status !== 'Running') {
        clearInterval(pollers[id]);
        $('runBtn').disabled = false;
        const res = await api('/api/jobs/' + id + '/result');
        $('output').classList.remove('empty');
        $('output').textContent = JSON.stringify(res, null, 2);
      }
    } catch (e) { clearInterval(pollers[id]); }
  }, 1000);
}

async function loadHealth() {
  try {
    const h = await api('/api/health');
    $('metrics').innerHTML = `
      <div class="metric"><div class="l">Host</div><div class="v">${h.computerName}</div></div>
      <div class="metric"><div class="l">CPU load</div><div class="v">${h.cpuPercent}%</div></div>
      <div class="metric"><div class="l">Memory used</div><div class="v">${h.memoryUsagePercent}%</div></div>
      <div class="metric"><div class="l">Free disk (C:)</div><div class="v">${h.diskFreeGB} GB</div></div>
      <div class="metric"><div class="l">Uptime</div><div class="v">${h.uptimeHours} h</div></div>
      <div class="metric"><div class="l">Pending reboot</div><div class="v">${h.pendingReboot ? 'Yes' : 'No'}</div></div>`;
  } catch (e) {
    $('metrics').innerHTML = `<div class="metric"><div class="l">Error</div><div class="v">${e.message}</div></div>`;
  }
}

loadKey();
loadCatalog();
loadHealth();
setInterval(loadHealth, 15000);
</script>
</body></html>
'@

function Write-MSPHttpJson($Response, $Obj, [int]$Code=200) {
    $Response.StatusCode = $Code
    $Response.ContentType = 'application/json'
    $bytes = [Text.Encoding]::UTF8.GetBytes(($Obj | ConvertTo-Json -Depth 10))
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.Close()
}

function Write-MSPHttpHtml($Response, $Html, [int]$Code=200) {
    $Response.StatusCode = $Code
    $Response.ContentType = 'text/html; charset=utf-8'
    $bytes = [Text.Encoding]::UTF8.GetBytes($Html)
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.Close()
}

function Test-MSPAuth($Request) {
    if ($Request.IsLocal -and -not $cfg.security.requireApiKeyForLocalhost) { return $true }
    return ($Request.Headers['X-Api-Key'] -eq $apiKey)
}

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $req = $ctx.Request; $res = $ctx.Response
        $path = $req.Url.AbsolutePath
        $method = $req.HttpMethod

        try {
            # Static
            if ($path -eq '/' -and $method -eq 'GET') {
                Write-MSPHttpHtml $res $uiHtml
                continue
            }

            # API auth
            if ($path -like '/api/*' -and -not (Test-MSPAuth $req)) {
                Write-MSPHttpJson $res @{ error = 'unauthorized' } 401
                continue
            }

            switch -Regex ($path) {
                '^/api/health$' {
                    $os = Get-CimInstance Win32_OperatingSystem
                    $cpu = (Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 1).CounterSamples.CookedValue
                    $diskC = Get-PSDrive C
                    Write-MSPHttpJson $res @{
                        computerName       = $env:COMPUTERNAME
                        cpuPercent         = [math]::Round($cpu)
                        memoryUsagePercent = [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize) * 100)
                        diskFreeGB         = [math]::Round($diskC.Free / 1GB, 1)
                        uptimeHours        = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalHours, 1)
                        pendingReboot      = (Test-MSPPendingReboot).PendingReboot
                        timestamp          = (Get-Date).ToString('o')
                    }
                    break
                }
                '^/api/scripts$' {
                    Write-MSPHttpJson $res $Script:Catalog
                    break
                }
                '^/api/scripts/run$' {
                    if ($method -ne 'POST') { Write-MSPHttpJson $res @{ error='method'} 405; break }
                    $body = (New-Object IO.StreamReader($req.InputStream)).ReadToEnd() | ConvertFrom-Json
                    $tool = $Script:Catalog | Where-Object id -eq $body.id | Select-Object -First 1
                    if (-not $tool) { Write-MSPHttpJson $res @{ error='unknown tool'} 404; break }

                    $scriptPath = Join-Path $PSScriptRoot $tool.path
                    if (-not (Test-Path $scriptPath)) { Write-MSPHttpJson $res @{ error="script missing: $scriptPath" } 500; break }

                    $sb = [scriptblock]::Create("& '$scriptPath'")
                    $jobId = New-MSPApiJob -Tool $tool.id -Block $sb -Args @{}
                    Write-MSPHttpJson $res @{ jobId = $jobId; tool = $tool.id; startedAt = (Get-Date).ToString('o') }
                    break
                }
                '^/api/jobs/(?<id>[a-f0-9]+)/result$' {
                    $id = $matches.id
                    $job = Update-MSPJobStatus -Id $id
                    if (-not $job) { Write-MSPHttpJson $res @{ error='not found'} 404; break }
                    Write-MSPHttpJson $res $job.Result
                    break
                }
                '^/api/jobs/(?<id>[a-f0-9]+)$' {
                    $id = $matches.id
                    $job = Update-MSPJobStatus -Id $id
                    if (-not $job) { Write-MSPHttpJson $res @{ error='not found'} 404; break }
                    Write-MSPHttpJson $res @{
                        id = $job.Id; tool = $job.Tool; status = $job.Status; startedAt = $job.StartedAt
                    }
                    break
                }
                '^/api/jobs$' {
                    $list = $Script:Jobs.Values | ForEach-Object {
                        @{ id=$_.Id; tool=$_.Tool; status=$_.Status; startedAt=$_.StartedAt }
                    }
                    Write-MSPHttpJson $res $list
                    break
                }
                '^/api/inventory$' {
                    $facts = Get-MSPOSFacts -Refresh
                    Write-MSPHttpJson $res $facts
                    break
                }
                default {
                    Write-MSPHttpJson $res @{ error = 'not found'; path = $path } 404
                }
            }
        } catch {
            Write-MSPLog "Request handler error: $_" -Level ERROR
            try { Write-MSPHttpJson $res @{ error = $_.Exception.Message } 500 } catch { }
        }
    }
}
finally {
    $listener.Stop(); $listener.Close()
    $Script:RunspacePool.Close(); $Script:RunspacePool.Dispose()
    Write-MSPLog 'API server stopped.' -Level INFO
}
