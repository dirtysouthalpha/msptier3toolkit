﻿@{
    RootModule        = 'MSPToolkit.psm1'
    ModuleVersion     = '8.0.0'
    GUID              = 'd5b1a0e2-9c5e-4f3d-8b8e-2b1f0a1f3c0a'
    Author            = 'MSP Tier 3 Toolkit contributors'
    CompanyName       = 'Open source / MSP community'
    Copyright         = '(c) MSP Tier 3 Toolkit contributors'
    Description       = 'High-impact automation toolkit for Tier-3 MSP engineers: diagnostics, fleet ops, M365/AD integration, REST API and fleet runner.'
    PowerShellVersion = '5.1'
    NestedModules     = @(
        'MSPToolkit.Config.psm1',
        'MSPToolkit.Logging.psm1',
        'MSPToolkit.Common.psm1',
        'MSPToolkit.Remote.psm1',
        'MSPToolkit.Fleet.psm1',
        'MSPToolkit.Playbook.psm1',
        'MSPToolkit.Tenant.psm1',
        'MSPToolkit.Audit.psm1',
        '..\Integrations\MSPToolkit.Notifications.psm1',
        '..\Integrations\MSPToolkit.Graph.psm1',
        '..\Integrations\MSPToolkit.PSA.psm1'
    )
    FunctionsToExport = @(
        # Config
        'Get-MSPConfig','Set-MSPConfigValue','Initialize-MSPDirectories',
        'Test-MSPAdminRights','Get-MSPSystemInfo',
        # Logging
        'Initialize-MSPLogging','Write-MSPLog','Write-MSPProgress',
        'Show-MSPBanner','Show-MSPSuccess','Show-MSPError','Show-MSPBox','Write-MSPTable',
        # Common
        'Test-MSPElevation','Assert-MSPElevation','Get-MSPPaths',
        'Invoke-MSPWithRetry','New-MSPResult','Save-MSPResult',
        'Get-MSPOSFacts','Test-MSPPendingReboot','ConvertTo-MSPSize','Get-MSPSessionId',
        # Remote
        'Invoke-MSPRemoteScript','Invoke-MSPRemoteScriptFile',
        'Get-MSPRemoteComputerStatus','Import-MSPComputerList',
        'New-MSPCredential','Get-MSPCredential',
        # Fleet
        'Invoke-MSPFleet',
        # Playbooks
        'Invoke-MSPPlaybook',
        # Tenants
        'Set-MSPTenant','Get-MSPTenant','Remove-MSPTenant',
        'Select-MSPTenant','Get-MSPCurrentTenant','Invoke-MSPAcross',
        # Audit
        'Write-MSPAudit','Test-MSPAuditChain',
        # Notifications
        'Send-MSPTeamsMessage','Send-MSPSlackMessage','Send-MSPDiscordMessage',
        'Send-MSPEmail','Send-MSPNotification',
        # Graph
        'Set-MSPGraphCredential','Get-MSPGraphCredential',
        'Connect-MSPGraph','Invoke-MSPGraph',
        'Get-MSPGraphUser','Get-MSPGraphLicenseSummary',
        'Reset-MSPGraphUserPassword','Set-MSPGraphUserAccountState','Get-MSPGraphSignInRisk',
        # PSA
        'New-MSPTicket'
    )
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
    PrivateData = @{
        PSData = @{
            Tags         = @('MSP','Tier3','Helpdesk','Automation','Diagnostics','Windows','M365','ActiveDirectory','RMM','PSA')
            ProjectUri   = 'https://github.com/dirtysouthalpha/msptier3toolkit'
            LicenseUri   = 'https://github.com/dirtysouthalpha/msptier3toolkit/blob/main/LICENSE'
            ReleaseNotes = 'v3.0.0 - Full overhaul: structured results, fleet runner, Graph integration, real REST API.'
        }
    }
}
